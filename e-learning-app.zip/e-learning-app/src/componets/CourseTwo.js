import React, { useState } from 'react';
import { Button, Input, Collapse, Layout, Row, Col } from 'antd';
import { LeftOutlined } from '@ant-design/icons';
import { addFakeQuizData } from '../firebase/actions';

const { Search } = Input;
const { Panel } = Collapse;
const { Content } = Layout;

const CourseTwo = ({ onBack }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const handleSearch = (value) => {
        setSearchTerm(value);
    };

    const handleGenerateQuizData = () => {
        addFakeQuizData(); // Call the function to generate and add fake quizzes
    };

    return (
        <Layout style={{ backgroundColor: '#f0f2f5', minHeight: '100vh' }}>
            <Content style={{ padding: '20px 50px' }}>
                {/* Back Button */}
                <Row justify="space-between" align="middle">
                    <Col>
                        <Button type="link" onClick={onBack} style={{ paddingLeft: 0 }}>
                            <LeftOutlined /> Back
                        </Button>
                        {/* <Button type="primary" onClick={handleGenerateQuizData}>
                            Add Fake Quiz Data
                        </Button> */}
                    </Col>

                    {/* Search Bar */}
                    <Col>
                        <Search
                            placeholder="Search for Quizzes"
                            allowClear
                            enterButton
                            onSearch={handleSearch}
                            style={{ width: 300, borderRadius: '20px' }}
                        />
                    </Col>
                </Row>

                {/* Course Content Header */}
                <h2 style={{ marginTop: '20px' }}>Course 2: Quizzes Overview</h2>

                {/* Accordion for Quizzes Content */}
                <Collapse accordion style={{ marginTop: '20px' }}>
                    <Panel header="Quiz 1: JavaScript Basics" key="1">
                        <p>Test your knowledge on JavaScript basics with this quiz.</p>
                    </Panel>
                    <Panel header="Quiz 2: React Components" key="2">
                        <p>Assess your understanding of React components and state management.</p>
                    </Panel>
                    <Panel header="Quiz 3: Redux Overview" key="3">
                        <p>Test your knowledge on Redux and how it handles state in a React application.</p>
                    </Panel>
                    <Panel header="Quiz 4: CSS Flexbox and Grid" key="4">
                        <p>Test your knowledge on CSS layout techniques such as Flexbox and Grid.</p>
                    </Panel>
                    <Panel header="Quiz 5: Node.js Basics" key="5">
                        <p>Assess your understanding of server-side development using Node.js.</p>
                    </Panel>
                </Collapse>
            </Content>
        </Layout>
    );
};

export default CourseTwo;
