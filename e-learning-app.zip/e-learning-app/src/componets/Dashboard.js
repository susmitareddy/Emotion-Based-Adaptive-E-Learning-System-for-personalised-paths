import React, { useState, useRef, useEffect } from 'react';
import { Button, Card, Layout, Row, Col, Modal, Input ,message} from 'antd';
import { addTypingData } from '../firebase/actions';
import { RightOutlined } from '@ant-design/icons';
import Webcam from 'react-webcam'; // Importing react-webcam
import * as faceapi from 'face-api.js'; // Import face-api.js
import { logout } from '../firebase/authActions';

const { Header, Content } = Layout;
const { TextArea } = Input;

function Dashboard({ onCardSelect }) {
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [note, setNote] = useState('');
    const lastKeyPressTime = useRef(0);
    const typingStartTime = useRef(0);
    const [charCount, setCharCount] = useState(0);
    const [emotion, setEmotion] = useState('neutral'); // State for detected emotion

    const webcamRef = useRef(null); // Ref for webcam
    const canvasRef = useRef(null); // Ref for canvas to draw face detection

    // Typing data
    const [typingData, setTypingData] = useState({
        backspaceCount: 0,
        pauseDurations: [],
        typingSpeed: 0,
    });

    useEffect(() => {
        if (charCount > 0) {
            const timeElapsedInMinutes = (Date.now() - typingStartTime.current) / 60000;
            const charsPerMinute = Math.round(charCount / timeElapsedInMinutes);

            setTypingData((prevData) => ({
                ...prevData,
                typingSpeed: charsPerMinute,
            }));
        }
    }, [charCount]);

    // Load face-api.js models
    const loadModels = async () => {
        await faceapi.nets.tinyFaceDetector.loadFromUri('/models');
        await faceapi.nets.faceExpressionNet.loadFromUri('/models');
    };

    // Detect emotions using face-api.js
    const detectEmotions = async () => {
        if (webcamRef.current && webcamRef.current.video.readyState === 4) {
            const video = webcamRef.current.video;

            const videoWidth = video.videoWidth;
            const videoHeight = video.videoHeight;

            if (videoWidth === 0 || videoHeight === 0) {
                console.warn('Video dimensions are invalid, skipping detection');
                return;
            }

            canvasRef.current.width = videoWidth;
            canvasRef.current.height = videoHeight;

            const detections = await faceapi
                .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
                .withFaceExpressions();

            if (detections.length > 0) {
                const emotions = detections[0].expressions;
                const dominantEmotion = Object.keys(emotions).reduce((a, b) =>
                    emotions[a] > emotions[b] ? a : b
                );
                setEmotion(dominantEmotion); // Update the emotion state
            }

            const displaySize = { width: videoWidth, height: videoHeight };
            faceapi.matchDimensions(canvasRef.current, displaySize);

            const resizedDetections = faceapi.resizeResults(detections, displaySize);

            const canvas = canvasRef.current;
            const context = canvas.getContext('2d');
            context.clearRect(0, 0, canvas.width, canvas.height);
            faceapi.draw.drawDetections(canvas, resizedDetections);
            faceapi.draw.drawFaceExpressions(canvas, resizedDetections);
        }
    };

    // Start emotion detection once models are loaded
    useEffect(() => {
        loadModels().then(() => {
            const interval = setInterval(detectEmotions, 1000); // Detect emotion every second
            return () => clearInterval(interval);
        });
    }, []);

    // Mouse movement tracking
    useEffect(() => {
        let lastMousePosition = { x: 0, y: 0 };
        let lastMouseMoveTime = Date.now();
        let erraticMovementCount = 0; // Counter for erratic movements
        let totalMovementCount = 0; // Total number of movements
        let totalSpeed = 0; // Total speed for averaging
        const erraticMovementThreshold = 3; // Set threshold for erratic movements
        const timeWindow = 2000; // Time window in milliseconds (2 seconds)
        const trackingDuration = 180000; // 3 minutes in milliseconds
        const endTrackingTime = Date.now() + trackingDuration; // Calculate end time

        // Stop tracking after 3 minutes
        const stopTracking = setTimeout(() => {
            window.removeEventListener('mousemove', handleMouseMove);

            // Summarize movement metrics
            const averageSpeed = totalSpeed / totalMovementCount || 0; // Calculate average speed
            console.log(`Summary after 3 minutes:`);
            console.log(`- Total mouse movements: ${totalMovementCount}`);
            console.log(`- Erratic movements detected: ${erraticMovementCount}`);
            console.log(`- Average movement speed: ${averageSpeed.toFixed(2)}`);
        }, trackingDuration);

        // Mouse movement handler
        const handleMouseMove = (event) => {
            const currentTime = Date.now();

            // Stop if the time has exceeded 3 minutes
            if (currentTime > endTrackingTime) return;

            const timeDiff = currentTime - lastMouseMoveTime;
            const speed = Math.sqrt(
                (event.clientX - lastMousePosition.x) ** 2 + (event.clientY - lastMousePosition.y) ** 2
            ) / timeDiff;

            totalMovementCount += 1; // Count total movements
            totalSpeed += speed; // Sum speeds for averaging

            if (speed > 0.5) {
                erraticMovementCount += 1;
            }

            lastMousePosition = { x: event.clientX, y: event.clientY };
            lastMouseMoveTime = currentTime;
        };

        // Start tracking mouse movements
        window.addEventListener('mousemove', handleMouseMove);

        return () => {
            // Cleanup: Remove event listener and clear timeout if component unmounts
            window.removeEventListener('mousemove', handleMouseMove);
            clearTimeout(stopTracking);
        };
    }, []);

    const showModal = () => {
        setIsModalVisible(true);
        typingStartTime.current = Date.now(); // Start tracking typing time when the modal is shown
        setTypingData({
            backspaceCount: 0,
            pauseDurations: [],
            typingSpeed: 0,
        });
    };

    const handleOk = () => {
        console.log('Note:', note);
        console.log('Typing Data:', typingData);
        addTypingData(typingData);
        setIsModalVisible(false);
        setNote(''); // Clear the note input after submitting
        setCharCount(0); // Reset character count
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };

    const handleTyping = (e) => {
        const currentTime = Date.now();

        // Detect pauses (more than 1 second between key presses)
        if (lastKeyPressTime.current !== 0) {
            const timeSinceLastKey = currentTime - lastKeyPressTime.current;
            if (timeSinceLastKey > 1000) {
                setTypingData((prevData) => ({
                    ...prevData,
                    pauseDurations: [...prevData.pauseDurations, timeSinceLastKey],
                }));
            }
        }
        lastKeyPressTime.current = currentTime;

        // Detect backspace key
        if (e.key === 'Backspace') {
            setTypingData((prevData) => ({
                ...prevData,
                backspaceCount: prevData.backspaceCount + 1,
            }));
        }

        setCharCount((prevCount) => prevCount + 1);
    };

    const handleLogout = async () => {
        try {
            await logout();
            message.success('Successfully logged out');
            // Add any post-logout actions here, like redirecting to the login page
        } catch (error) {
            message.error(`Logout failed: ${error.message}`);
        }
    };

    return (
        <>
            <Layout style={{ minHeight: '100vh' }}>
                <Header style={{ background: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 20px' }}>
                    <h1 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0, textAlign: 'center', flex: 1 }}>
                        E_LEARNING_APP
                    </h1>

                    <Button type="primary" style={{ fontSize: '14px', padding: '6px 16px' }} onClick={showModal}>
                        Add Note
                    </Button>
                    <Button type="default" style={{ fontSize: '14px', padding: '6px 16px' }} onClick={handleLogout}>
                        Logout
                    </Button>
                </Header>

                <Content style={{ padding: '50px' }}>
                    <h2 style={{ textAlign: 'left' }}>My Courses</h2>
                    <Row gutter={[24, 24]} justify="start">
                        {/* New card for the video and emotion detection */}
                        <Col xs={24} sm={12} lg={10}>
                            <Card
                                hoverable
                                style={{
                                    background: 'linear-gradient(90deg, #0093E9 0%, #80D0C7 100%)',
                                    borderRadius: '12px',
                                    color: '#fff',
                                    minHeight: '300px',
                                    textAlign: 'center',
                                }}
                            >
                                <Webcam
                                    ref={webcamRef}
                                    style={{
                                        width: '100%',
                                        borderRadius: '12px',
                                        marginBottom: '10px',
                                    }}
                                    videoConstraints={{ width: 640, height: 480 }}
                                />
                                <canvas
                                    ref={canvasRef}
                                    style={{
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        zIndex: 1,
                                        width: 640,
                                        height: 480,
                                    }}
                                />
                                <h2>Hello, Welcome back!</h2>
                                <h3>Looks like you are: <strong>{emotion}</strong></h3>
                            </Card>
                        </Col>

                        <Col xs={24} sm={12} lg={10}>
                            <Card
                                hoverable
                                style={{
                                    background: 'linear-gradient(90deg, #0093E9 0%, #80D0C7 100%)',
                                    borderRadius: '12px',
                                    color: '#fff',
                                    minHeight: '150px',
                                }}
                                onClick={() => onCardSelect('course2')}
                            >
                                <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%' }}>
                                    <div>
                                        <h3>Quizzes</h3>
                                        <p>Test your knowledge and improve your skills.</p>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <span style={{ color: 'white' }}>Go to Course <RightOutlined /></span>
                                    </div>
                                </div>
                            </Card>
                        </Col>

                        <Col xs={24} sm={12} lg={10}>
                            <Card
                                hoverable
                                style={{
                                    background: 'linear-gradient(90deg, #0093E9 0%, #80D0C7 100%)',
                                    borderRadius: '12px',
                                    color: '#fff',
                                    minHeight: '150px',
                                }}
                                onClick={() => onCardSelect('course1')}
                            >
                                <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%' }}>
                                    <div>
                                        <h3>Lessons</h3>
                                        <p>Learn at your own pace and master the topics.</p>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <span style={{ color: 'white' }}>Go to Course <RightOutlined /></span>
                                    </div>
                                </div>
                            </Card>
                        </Col>
                    </Row>
                </Content>
            </Layout>

            {/* Modal for adding notes */}
            <Modal
                title="Add Note"
                open={isModalVisible}
                onOk={handleOk}
                onCancel={handleCancel}
                okText="Save"
                cancelText="Cancel"
            >
                <TextArea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    onKeyDown={handleTyping}
                    placeholder="Write your note here..."
                    rows={4}
                />
            </Modal>
        </>
    );
}

export default Dashboard;
