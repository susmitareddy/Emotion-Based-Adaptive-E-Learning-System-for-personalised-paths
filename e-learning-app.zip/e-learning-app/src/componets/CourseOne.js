import React from 'react';
import { Button, Input, Collapse, Layout, Row, Col } from 'antd';
import { LeftOutlined } from '@ant-design/icons';
import { addFakeCourseData } from '../firebase/actions';


const { Search } = Input;
const { Panel } = Collapse;
const { Content } = Layout;

const CourseOne = ({ onBack }) => {
    const handleSearch = (value) => {
        console.log('Search value:', value);
    };

    const handleGenerateData = () => {
        addFakeCourseData(); // Call the function to generate fake data
    }; 

    return (
        <Layout style={{ backgroundColor: '#f0f2f5', minHeight: '100vh' }}>
            <Content style={{ padding: '20px 50px' }}>
                {/* Back Button */}
                <Row justify="space-between" align="middle">
                    <Col>
                        <Button type="link" onClick={onBack} style={{ paddingLeft: 0 }}>
                            <LeftOutlined /> Back
                        </Button>
                        {/* <Button type="primary" onClick={handleGenerateData}> */}
                            {/* Add Fake Course Data */}
                        {/* </Button> */}
                    </Col>

                    {/* Search Bar */}
                    <Col>
                        <Search
                            placeholder="Search for Courses"
                            allowClear
                            enterButton
                            onSearch={handleSearch}
                            style={{ width: 300, borderRadius: '20px' }}
                        />
                    </Col>
                </Row>

                {/* Course Content */}
                <h2 style={{ marginTop: '20px' }}>Courses Overview</h2>

                {/* Accordion for Course Modules */}
                <Collapse accordion style={{ marginTop: '20px' }}>
                    <Panel header="01. IIM ABC: LRDI Module 1" key="1">
                        <p>Details about LRDI Module 1</p>
                    </Panel>
                    <Panel header="01. IIM ABC: RC Module 1" key="2">
                        <p>Details about RC Module 1</p>
                    </Panel>
                    <Panel header="02. IIM ABC: LRDI Module 2" key="3">
                        <p>Details about LRDI Module 2</p>
                    </Panel>
                    <Panel header="02. IIM ABC: RC Module 2" key="4">
                        <p>Details about RC Module 2</p>
                    </Panel>
                    <Panel header="03. IIM ABC: LRDI Module 3" key="5">
                        <p>Details about LRDI Module 3</p>
                    </Panel>
                    <Panel header="03. IIM ABC: RC Module 3" key="6">
                        <p>Details about RC Module 3</p>
                    </Panel>
                </Collapse>
            </Content>
        </Layout>
    );
};

export default CourseOne;
