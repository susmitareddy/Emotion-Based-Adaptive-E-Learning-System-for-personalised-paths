import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "./firebase";
import { signOut } from "firebase/auth";

export const login = async (email, password) => {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error) {

        throw new Error(error.message);
    }
};

export const logout = async () => {
    try {
        await signOut(auth);
        console.log("User logged out successfully");
    } catch (error) {
        console.error("Logout Error:", error.message);
        throw new Error("Failed to log out");
    }
};