import { collection, addDoc, Timestamp } from "firebase/firestore";
import { db } from './firebase';
import { faker } from '@faker-js/faker';

export const addTypingData = async (typingData) => {
    try {
        // Create a new document in the "typingData" collection
        const docRef = await addDoc(collection(db, "typingData"), {
            backspaceCount: typingData.backspaceCount,
            pauseDurations: typingData.pauseDurations,
            typingSpeed: typingData.typingSpeed,
            timestamp: Timestamp.now() // Firebase timestamp
        });

        console.log("Document written with ID: ", docRef.id);
    } catch (e) {
        console.error("Error adding document: ", e);
    }
};



export const addFakeCourseData = async () => {
    try {
        const courseCollection = collection(db, 'courses'); // Firestore collection named "courses"

        // Generate 10 fake courses
        for (let i = 0; i < 10; i++) {
            const courseData = {
                courseName: faker.company.name(), // Correct method name
                description: faker.lorem.sentences(3), // Random description
                modules: [
                    {
                        moduleTitle: `Module 1: ${faker.commerce.productName()}`,
                        content: faker.lorem.paragraphs(2),
                    },
                    {
                        moduleTitle: `Module 2: ${faker.commerce.productName()}`,
                        content: faker.lorem.paragraphs(2),
                    },
                    {
                        moduleTitle: `Module 3: ${faker.commerce.productName()}`,
                        content: faker.lorem.paragraphs(2),
                    },
                ],
                createdAt: faker.date.past(), // Random past date
            };

            // Add the fake course data to the Firestore collection
            await addDoc(courseCollection, courseData);
            console.log('Course added: ', courseData.courseName);
        }
    } catch (e) {
        console.error('Error adding document: ', e);
    }
};


export const addFakeQuizData = async () => {
    try {
        const quizCollection = collection(db, 'quizzes'); // Firestore collection named "quizzes"

        // Generate 10 fake quizzes
        for (let i = 0; i < 10; i++) {
            const quizData = {
                quizTitle: `Quiz ${i + 1}: ${faker.company.catchPhrase()}`, // Generate quiz title
                description: faker.lorem.sentences(2), // Generate a random description
                questions: [
                    {
                        question: faker.lorem.sentence(),
                        options: [
                            faker.lorem.word(),
                            faker.lorem.word(),
                            faker.lorem.word(),
                            faker.lorem.word(),
                        ],
                        correctAnswer: faker.lorem.word(),
                    },
                    {
                        question: faker.lorem.sentence(),
                        options: [
                            faker.lorem.word(),
                            faker.lorem.word(),
                            faker.lorem.word(),
                            faker.lorem.word(),
                        ],
                        correctAnswer: faker.lorem.word(),
                    },
                ],
                createdAt: faker.date.past(), // Random past date
            };

            // Add the fake quiz data to Firestore
            await addDoc(quizCollection, quizData);
            console.log('Quiz added:', quizData.quizTitle);
        }
    } catch (e) {
        console.error('Error adding document:', e);
    }
};