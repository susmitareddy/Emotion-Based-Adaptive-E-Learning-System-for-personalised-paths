// AuthContext.js
import React, { createContext, useContext, useEffect, useReducer } from "react";
import { auth } from "../../src/firebase/firebase";
import { onAuthStateChanged } from "firebase/auth";

const AuthContext = createContext();

export function useAuth() {
    return useContext(AuthContext);
}

const initialState = {
    currentUser: null,
    loading: true,
    authError: null,
};

const authReducer = (state, action) => {
    switch (action.type) {
        case 'LOGIN':
            return {
                ...state,
                currentUser: action.payload,
                loading: false,
                authError: null,
            };
        case 'LOGOUT':
            return {
                ...state,
                currentUser: null,
                loading: false,
                authError: null,
            };
        case 'SET_LOADING':
            return {
                ...state,
                loading: action.payload,
            };
        case 'SET_ERROR': // Handle authentication errors
            return {
                ...state,
                authError: action.payload,
            };
        default:
            return state;
    }
};

export function AuthProvider({ children }) {
    const [state, dispatch] = useReducer(authReducer, initialState);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                // User is logged in
                dispatch({ type: 'LOGIN', payload: user });
                localStorage.setItem('user', JSON.stringify(user));
            } else {
                // User is logged out
                dispatch({ type: 'LOGOUT' });
                localStorage.removeItem('user');
            }
        });

        return unsubscribe;
    }, []);

    const clearError = () => {
        dispatch({ type: 'SET_ERROR', payload: null });
    };

    const value = {
        currentUser: state.currentUser,
        loading: state.loading,
        authError: state.authError,
        clearError,
    };

    return (
        <AuthContext.Provider value={value}>
            {!state.loading && children}
        </AuthContext.Provider>
    );
}
