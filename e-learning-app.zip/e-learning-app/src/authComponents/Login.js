import React from 'react';
import { Form, Input, Button, Card } from 'antd';
import { login } from '../firebase/authActions';
import './Login.css'; // Import custom CSS for styling
import { useNavigate } from 'react-router-dom';

function Login() {
    const navigate = useNavigate();
    const onFinish = async (values) => {
        try {
            const user = await login(values.email, values.password);
            console.log('Login Success:', user);
            navigate('/');
        } catch (error) {
            console.log('Login Failed:', error.message);
        }
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Login Failed:', errorInfo);
    };

    return (
        <div className="login-container">
            <Card title="Login" className="login-card">
                <Form
                    name="login_form"
                    initialValues={{ remember: true }}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    layout="vertical"
                >
                    {/* Email Field */}
                    <Form.Item
                        label="Email"
                        name="email"
                        rules={[
                            { required: true, message: 'Please enter your email' },
                            { type: 'email', message: 'Please enter a valid email' },
                        ]}
                    >
                        <Input placeholder="Enter your email" />
                    </Form.Item>

                    {/* Password Field */}
                    <Form.Item
                        label="Password"
                        name="password"
                        rules={[{ required: true, message: 'Please enter your password' }]}
                    >
                        <Input.Password placeholder="Enter your password" />
                    </Form.Item>

                    {/* Login Button */}
                    <Form.Item>
                        <Button type="primary" htmlType="submit" className="login-button" block>
                            Login
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
}

export default Login;
